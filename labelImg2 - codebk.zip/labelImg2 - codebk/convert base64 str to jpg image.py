'''
批次將base64檔案轉成JPG，不修改大小
'''

import base64, glob

def base64_file_to_jpg_img_file(base64_file_path=None, base64_file_name=None, target_image_path=None):
    base64_file = open(base64_file_path+'\\'+base64_file_name, 'rb')
    base64_str = base64_file.read()
    # print(len(base64_str))
    image_64_decode = base64.decodebytes(base64_str)
    file_name = base64_file_name.split('.')[0]
    image_result = open(target_image_path+'\\'+file_name+'.jpg', 'wb') # create a writable image and write the decoding result
    image_result.write(image_64_decode)
    base64_file.close()
    image_result.close()


base64_file_path = r'D:\Data\3206\0320_id\C001_10000'
# base64_file_name = 'HN200226788202_A001.txt'
target_image_path = r'D:\Data\3206\0320_id\C001_JPG'
# base64_file_to_jpg_img_file(base64_file_path=base64_file_path, base64_file_name=base64_file_name, target_image_path=target_image_path)

files = glob.glob(base64_file_path+'\\*.txt')
for b_file in files:
    base64_file_name = b_file.split('\\')[-1]
    print('base64_file_name : {}'.format(base64_file_name))
    base64_file_to_jpg_img_file(base64_file_path=base64_file_path, base64_file_name=base64_file_name, target_image_path=target_image_path)
print('process {} base64 files to {} image folder done.'.format(base64_file_path, target_image_path))
