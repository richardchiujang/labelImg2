from libs.pascal_voc_io import PascalVocReader
from libs.pascal_voc_io import PascalVocWriter
from libs.pascal_voc_io import XML_EXT
from libs.labelFile import LabelFile, LabelFileError

from libs import generate_gt_anchor

from os import walk
import os.path
import sys
import math 
import cv2

try:
    from PyQt5.QtGui import QImage
except ImportError:
    from PyQt4.QtGui import QImage


def readPascalVocFormat(filename, imagePath):
    '''
    讀出既有的XML 將 textbox label 轉成 text label 
    '''
    print(filename) # , imagePath
    tVocParseReader = PascalVocReader(filename)
    shapes = tVocParseReader.getShapes()
    # print(shapes, '\n')

    newtext = []
    for shape in shapes:
        # newtext = []
        if shape[0]=='text':
            # {'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(84.0, 305.0), (99.0, 305.0), (99.0, 321.0), (84.0, 321.0)], 'difficult': False} # 要轉成這樣
            # ('text', [(52, 305), (67, 305), (67, 321), (52, 321)], None, None, False)  # 原本的shape
            # {'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': shape[1], 'difficult': False}
            newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': shape[1], 'difficult': False})
            # print(newtext, '\n')
            # pass
        elif shape[0]=='textbox':    
            # ('textbox', [(224, 273), (313, 273), (313, 298), (224, 298)], None, None, False)   # 這是正長方形
            #           # [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
            # ('textbox', [(138.66131443809627, 186.31882328959517), (386.4210441699288, 200.27872445326022), (384.33408556190375, 237.31797671040482), (136.57435583007123, 223.35807554673977)], None, None, False, True, 0.056285) # 這是傾斜長方形
            # if shape[5]=='True'
            # newtext = []
            if len(shape)>5: # 這是傾斜長方形
                # 這裡用了一個 https://www.cnblogs.com/skyfsm/p/10054386.html 的code拿來改的 from libs import generate_gt_anchor ...
                img = cv2.imread(imagePath)
                box = [item for elem in [list(s) for s in shape[1]] for item in elem]  # 做成一個平的list 去除巢狀 
                # print(box)
                rr, pt=generate_gt_anchor.generate_gt_anchor(img, box, anchor_width=16, draw_img_gt=img)     # anchor_width=16 框就是i+15共16點，i自己是起點 , draw_img_gt=img
                # print(rr)
                # print(pt)  # [[(128, 331), (143, 331), (143, 362), (128, 362)], [(144, 329), (159, 329), (159, 361), (144, 361)]]
                for p in pt:
                    newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': p, 'difficult': False})
                pass
            else: # 這是正長方形
                xmin = shape[1][0][0] # 左邊點
                xmax = shape[1][1][0] 
                ymin = shape[1][0][1]
                ymax = shape[1][2][1]        
                xlen = xmax - xmin  # 計算長度
                nbox = math.ceil(xlen/16) # 計算框數 (頂數)
                leftx = xmin # 小框的左邊點
                rightx = xmin + 15  # 往右邊15點(小框的右邊點)
                for j in range(nbox):
                    newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
                    leftx = rightx + 1  # 小框右邊界 右移 1點
                    rightx = leftx + 15 # 小框左邊界 往右15點
                # while leftx < xmax: # 小框左邊點 < 大框的右邊界，就加上這個框然後在算下一個框的左右點
                #     # newtext.append(('text', [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], None, None, False))
                #     newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (min(rightx,xmax), ymin), (min(rightx,xmax), ymax), (leftx, ymax)], 'difficult': False})
                #     leftx = rightx + 1  # 小框右邊界 右移 1點
                #     rightx = leftx + 15 # 小框左邊界 往右15點
                # else: # 小框左邊點 >= 大框的右邊界 (就是超過了啊!) 就跳過不加框
                #     pass
                #     # if rightx == xmax: # 小框右邊點剛好是大框最右邊點，加上這個框然後結束
                #     #     newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
                #     # else: # 小框右邊點 > 大框的右邊界 ，就畫上最後一格(右邊限制在大框右邊界)
                #     #     newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (xmax, ymin), (xmax, ymax), (leftx, ymax)], 'difficult': False})

    # for ntext in newtext:
    #     print(ntext, '\n')
    shapes =  newtext
    return shapes

def savePascalVocFormat(filename, shapes, imagePath, lineColor=None, fillColor=None, databaseSrc=None):
    imgFolderPath = os.path.dirname(imagePath)
    imgFolderName = os.path.split(imgFolderPath)[-1]
    imgFileName = os.path.basename(imagePath)
    #imgFileNameWithoutExt = os.path.splitext(imgFileName)[0]
    # Read from file path because self.imageData might be empty if saving to
    # Pascal format
    image = QImage()
    image.load(imagePath)
    imageShape = [image.height(), image.width(),
                    1 if image.isGrayscale() else 3]
    writer = PascalVocWriter(imgFolderName, imgFileName,
                                imageShape, localImgPath=imagePath)
    # writer.verified = verified

    for shape in shapes:
        # print('shape:\n', shape)
        points = shape['points']
        label = shape['label']
        extra = None 
        # Add Chris
        difficult = int(shape['difficult'])
        bndbox = LabelFile.convertPoints2BndBox(points)
        writer.addBndBox(bndbox[0], bndbox[1], bndbox[2], bndbox[3], label, difficult, extra)

    writer.save(targetFile=filename)
    return


def main():
    '''
    這是讀取標籤xml檔 將大文字框框 改成小文字框 然後存回xml檔案
    邏輯 : 遇到 textbox 就會處理 遇到 text 就保留不動
    記得最後搬到目的資料夾後，再執行一次，他就會修正XML裡面的影像路徑為最後的路徑
    會同時處理水平跟傾斜的框
    '''
    spath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\id_data\\'
    # spath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\temp_id_data\\'
    
    # smode = 'IB0019\\'
    # smode = 'IC0019\\'
    # smode = 'IA0019\\'
    # smode = 'IX0090\\'  'IA0029\\','IC0019\\',
    smodes = ['IA0029\\']    # ['IA0011','IA0012','IA0013','IA0014','IA0019']   ,'IC0019\\','IB0019\\','IA0019\\'

    for smode in smodes:
        for (dirpath, dirnames, filenames) in walk(spath+smode):
            all_files = filenames
            break # 就是只抓一層

        # all_files=['HN191221781307_A001.xml']
        i=0
        for nfile in all_files[:]:
            if nfile.split('.')[-1] != 'xml':
                pass
            else:
                i+=1
                imagePath = spath+smode + nfile.split('.')[0] + '.jpg'
                filename = spath+smode + nfile
                # tVocParseReader = PascalVocReader(filename)
                # shapes = tVocParseReader.getShapes()
                shapes = readPascalVocFormat(filename, imagePath)  # imagePath 傾斜矩形需要讀圖來產生框位置
                savePascalVocFormat(filename=filename, imagePath=imagePath, shapes=shapes)
        print('mode {} {} tot item finished.'.format(smode, i))
    return print('all job done.')


if __name__ == "__main__":
    main()
else:
    print('load xml-parser ok')


