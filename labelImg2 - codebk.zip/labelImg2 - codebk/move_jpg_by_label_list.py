'''
從清單搬檔案出來並建立一個清單 labels.txt
'''
import shutil

spath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\temp_clip_data\\'
mode = 'IA0027\\'     #'IB0014\\'  'IA0027\\' 'IA0028\\'
temp_hub = 'temp_hub\\'
lbfile = 'outstr_地址(上).txt'        # 'outstr_地址(下).txt'     # 'outstr_駕照種類.txt'   outstr_地址(上).txt

fp = open(spath+lbfile, 'r', encoding='utf-8')
for line in iter(fp):
    print(line)
    shutil.copy(spath + mode + line.split(' ')[0], spath + temp_hub + line.split(' ')[0])
fp.close()

shutil.copy(spath+lbfile, spath + temp_hub + 'labels.txt')
