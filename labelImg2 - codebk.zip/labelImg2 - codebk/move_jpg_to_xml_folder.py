
'''
根據XML清單搬移JPG檔案過來
'''


import os
import shutil 
spath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\temp_id_data\\IA0000\\'
cpath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\temp_id_data\\IA0029\\'   # IA0029   IB0019
    
for (dirpath, dirnames, filenames) in os.walk(spath):
    all_files = filenames
    break # 就是只抓一層

i=0
for nfile in all_files[:]:
    if nfile.split('.')[-1] != 'xml':
        pass
    else:
        i+=1
        imagePath = cpath + nfile.split('.')[0] + '.jpg'
        shutil.move(imagePath, spath)

print('{} files copy'.format(i))

