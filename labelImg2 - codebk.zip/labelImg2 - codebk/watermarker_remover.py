import cv2
import numpy as np
import os


def remove_watermarker(rpath=None, tpath=None):
    rpath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\id_data\\IX0094s\\'
    tpath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\id_data\\IX0094\\'
    # # filename = 'HQ200226792332_A002.jpg'
    # # path = rpath+filename
    # # 255 0 0 0.5
    # # lower_red = np.array([70, 70, 200])
    # # upper_red = np.array([160, 160, 255])
    # lower_red = np.array([100, 100, 180])
    # upper_red = np.array([210, 210, 255])
    # # img = cv2.imread(path, cv2.IMREAD_UNCHANGED)
    # # print(img.shape)
    # # hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)


    for (dirpath, dirnames, filenames) in os.walk(rpath):
        all_files = filenames[:]
        break # 就是只抓一層

    for thisfile in all_files:
        if thisfile.__contains__('_B001'):
            lower_red = np.array([120, 120, 200])
            upper_red = np.array([210, 210, 255])
        else:
            lower_red = np.array([70, 70, 170])
            upper_red = np.array([210, 210, 255])

        img = cv2.imread(rpath+thisfile, cv2.IMREAD_UNCHANGED)
        print(thisfile, img.shape, all_files.index(thisfile), img.mean(), img[:,:,:1].mean(), img[:,:,1:2].mean(), img[:,:,2:3].mean())
    # mask -> 1 channel
        mask = cv2.inRange(img, lower_red, upper_red) #lower20===>0,upper200==>0
    # scan = np.ones( (3,3),np.uint8)
    # cor = cv2.dilate(mask,scan,iterations=1)
    # specular = cv2.inpaint(img,cor,5,flags=cv2.INPAINT_TELEA)
        specular = cv2.inpaint(img,mask,5,flags=cv2.INPAINT_TELEA)
    #操作結束，下面開始是輸出圖片的代碼
        # cv2.namedWindow("image", cv2.WINDOW_KEEPRATIO)
        # cv2.imshow("image",img)
        # cv2.imwrite(tpath+thisfile, img)
        # cv2.namedWindow("mask", cv2.WINDOW_KEEPRATIO)
        # cv2.imshow("mask",mask)
        # cv2.imwrite(rpath+thisfile.split('.jpg')[0]+'_mask.jpg', mask)
        # cv2.namedWindow("modified", cv2.WINDOW_KEEPRATIO)
        # cv2.imshow("modified",specular)
        # cv2.imwrite(tpath+thisfile.split('.jpg')[0]+'modified.jpg', specular)
        cv2.imwrite(tpath+thisfile, specular)
        # cv2.waitKey(0)
        # cv2.destroyAllWindows()




def move_jpg_list(spath, tpath, files):
    ''' remove then create again tpath and copy all files from spath to tpath '''
    import os
    import shutil
    if os.path.isdir(tpath):
        shutil.rmtree(tpath)     # delete all files in target folder
    os.mkdir(tpath)    
    for f in files:
        shutil.copy(spath+f, tpath+f)
    return 0



def main():
    remove_watermarker()
    #  tot acc:  0.915 17 200 
    # spath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\id_data\\IX0090T\\'
    # tpath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\id_data\\IX0094s\\'
    # files = ['HQ200221347768_B001.jpg','HQ200222347811_B001.jpg','HQ200222792132_B001.jpg','HQ200225347899_B001.jpg','HQ200226037613_B001.jpg','HQ200226792245_B001.jpg',
    # 'HQ200227570405_A002.jpg','HQ200227815337_C001.jpg','HQ200228348216_C001.jpg','HQ200228570579_C001.jpg','HQ200228792522_A002.jpg','HQ200228815388_B001.jpg',
    # 'HQ200229570724_A001.jpg','HQ200229815514_A001.jpg','HQ200229815547_A001.jpg','HQ200229815560_A001.jpg','HQ200301815617_A002.jpg']
    # print(move_jpg_list(spath, tpath, files))

if __name__ == "__main__":
    main()
else:
    print('pass')