from libs.pascal_voc_io import PascalVocReader
from libs.pascal_voc_io import PascalVocWriter
from libs.pascal_voc_io import XML_EXT
from libs.labelFile import LabelFile, LabelFileError

from libs import generate_gt_anchor

from os import walk
import os.path
import os
import sys
import cv2
import math 

try:
    from PyQt5.QtGui import QImage
except ImportError:
    from PyQt4.QtGui import QImage

def readPascalVocFormat(filename):
    '''
    Deprecated !!!
    讀出既有的XML 將 textbox label 轉成 text label 
    '''

    tVocParseReader = PascalVocReader(filename)
    shapes = tVocParseReader.getShapes()
    # print(shapes, '\n')

    newtext = []
    for shape in shapes:
        # newtext = []
        if shape[0]=='text':
            # {'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(84.0, 305.0), (99.0, 305.0), (99.0, 321.0), (84.0, 321.0)], 'difficult': False}
            # ('text', [(52, 305), (67, 305), (67, 321), (52, 321)], None, None, False)
            # {'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': shape[1], 'difficult': False}
            newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': shape[1], 'difficult': False})
            # print(newtext, '\n')
            pass
        elif shape[0]=='textbox':    
            # ('textbox', [(224, 273), (313, 273), (313, 298), (224, 298)], None, None, False)   
            #           # [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
            # newtext = []
            xmin = shape[1][0][0] # 左邊點
            xmax = shape[1][1][0] 
            ymin = shape[1][0][1]
            ymax = shape[1][2][1]
            xlen = xmax - xmin  # 計算長度
            nbox = math.ceil(xlen/16) 
            leftx = xmin # 小框的左邊點
            rightx = xmin + 15  # 往右邊15點(小框的右邊點)
            for j in range(nbox):
                newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
                leftx = rightx + 1  # 小框右邊界 右移 1點
                rightx = leftx + 15 # 小框左邊界 往右15點                    
            # while rightx < xmax: # 小框右邊點 < 大框的右邊界
            #     # newtext.append(('text', [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], None, None, False))
            #     newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
            #     leftx = rightx + 1  # 小框右邊界 右移 1點
            #     rightx = leftx + 15 # 小框左邊界 往右15點
            # else: # 小框右邊點 >= 大框的右邊界 ，就畫上最後一格
            #     # pass
            #     # 如果 rightx > xmax ( 超過 )  OR   rightx = xmax (相同) 為避免框框寬為0而出錯，所以一律 xmax+1 處理
            #     # newtext.append(('text', [(leftx, ymin), (xmax+1, ymin), (xmax+1, ymax), (leftx, ymax)], None, None, False))
            #     newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})

    # for ntext in newtext:
    #     print(ntext, '\n')
    shapes =  newtext
    return shapes

def savePascalVocFormat(filename, shapes, imagePath, lineColor=None, fillColor=None, databaseSrc=None):
    '''儲存成 XML'''

    imgFolderPath = os.path.dirname(imagePath)
    imgFolderName = os.path.split(imgFolderPath)[-1]
    imgFileName = os.path.basename(imagePath)
    #imgFileNameWithoutExt = os.path.splitext(imgFileName)[0]
    # Read from file path because self.imageData might be empty if saving to
    # Pascal format
    image = QImage()
    image.load(imagePath)
    imageShape = [image.height(), image.width(),
                    1 if image.isGrayscale() else 3]
    writer = PascalVocWriter(imgFolderName, imgFileName,
                                imageShape, localImgPath=imagePath)
    # writer.verified = verified

    for shape in shapes:
        # print('shape:\n', shape)
        points = shape['points']
        label = shape['label']
        extra = None 
        # Add Chris
        difficult = int(shape['difficult'])
        bndbox = LabelFile.convertPoints2BndBox(points)
        writer.addBndBox(bndbox[0], bndbox[1], bndbox[2], bndbox[3], label, difficult, extra)

    writer.save(targetFile=filename)
    return 

def createPascalshapesFormat(line):
    '''
    Deprecated !!! pls use new function createnewPascalshapesFormat()
    將 prepa_ctpn_longbox_n_img.py 處理的輸出 outbox.txt 讀近來轉成 shapes 給 savePascalVocFormat 輸出成XML格式
    這會把傾斜的框擴大為水平框而失真，改用 createnewPascalshapesFormat()
    '''

    nfilename, bbox = line.split('.jpg')[0]+'.jpg', eval(line.split('.jpg')[1])
    # print(nfilename, bbox, len(bbox), type(bbox))  # bbox is tuple
    '''
    # [190,  79, 623,  76, 191, 181, 623, 178,   0] 
    # 左[0]上[1]右[2]上[3]左[4]下[5]右[6]下[7]角度[8]
    # HN190928155389_A001.jpg [110, 330, 383, 328, 111, 357, 383, 355, 0],[446, 334, 639, 333, 447, 370, 639, 370, 0],[111, 184, 383, 184, 111, 228, 383, 228, 0],[110, 267, 383, 267, 111, 297, 383, 297, 0]
    # newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
    '''
    newtext = []
    for i in range(len(bbox)):
        if type(bbox)==list:
            box = bbox  # 只有一組時不會被拆開
        else:
            box = bbox[i]
        lx, uy, rx, dy = min(box[0],box[4]), min(box[1], box[3]), max(box[2], box[6]), max(box[5], box[7])
        points = [(lx, uy), (rx, uy), (rx, dy), (lx, dy)]
        newtext.append({'label': 'textbox', 'line_color': (60, 330, 100, 50), 'fill_color': (60, 330, 100, 50), 'points': points, 'difficult': False})
        shapes =  newtext
    return nfilename, shapes

def createnewPascalshapesFormat(line, imagePath):
    '''
    將 prepa_ctpn_longbox_n_img.py 處理的輸出 outbox.txt 讀近來轉成 shapes 給 savePascalVocFormat 輸出成XML格式
    切斜的box都會被切成text
    水平的都用原方法處理成text
    '''

    nfilename, bbox = line.split('.jpg')[0]+'.jpg', eval(line.split('.jpg')[1])
    # print(nfilename, bbox, len(bbox), type(bbox))  # bbox is tuple
    '''
    # [190,  79, 623,  76, 191, 181, 623, 178,   0] 
    # 左[0]上[1]右[2]上[3]左[4]下[5]右[6]下[7]角度[8]
    # HN190928155389_A001.jpg [110, 330, 383, 328, 111, 357, 383, 355, 0],[446, 334, 639, 333, 447, 370, 639, 370, 0],[111, 184, 383, 184, 111, 228, 383, 228, 0],[110, 267, 383, 267, 111, 297, 383, 297, 0]
    # newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
    '''
    img = cv2.imread(imagePath)
    newtext = []
    for i in range(len(bbox)):
        if type(bbox)==list:
            box = bbox  # 只有一組時不會被拆開
        else:
            box = bbox[i][:-1]
            if box[1]==box[3]: 
                # 高度一樣不是傾斜box 用元方法處理(標成 textbox) 
                # lx, uy, rx, dy = min(box[0], box[4]), min(box[1], box[3]), max(box[2], box[6]), max(box[5], box[7])
                # points = [(lx, uy), (rx, uy), (rx, dy), (lx, dy)]
                # newtext.append({'label': 'textbox', 'line_color': (60, 330, 100, 50), 'fill_color': (60, 330, 100, 50), 'points': points, 'difficult': False}) 
                xmin = min(box[0], box[4]) # 左邊點
                xmax = max(box[2], box[6]) 
                ymin = min(box[1], box[3])
                ymax = max(box[5], box[7])        
                xlen = xmax - xmin  # 計算長度
                nbox = math.ceil(xlen/16) 
                leftx = xmin # 小框的左邊點
                rightx = xmin + 15  # 往右邊15點(小框的右邊點)
                for j in range(nbox):
                    newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
                    leftx = rightx + 1  # 小框右邊界 右移 1點
                    rightx = leftx + 15 # 小框左邊界 往右15點
                # while rightx < xmax: # 小框右邊點 < 大框的右邊界，就加上這個框然後在算下一個框的左右點
                #     # newtext.append(('text', [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], None, None, False))
                #     newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
                #     leftx = rightx + 1  # 小框右邊界 右移 1點
                #     rightx = leftx + 15 # 小框左邊界 往右15點
                # else: # 下一個框
                #     if rightx == xmax: # 小框右邊點剛好是大框最右邊點，加上這個框然後結束
                #         newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})
                #     else: # 小框右邊點 > 大框的右邊界 ，就畫上最後一格
                #         # pass 
                #         newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False})            
            else: # 傾斜的box用工具
                # print(box)
                rr, pt=generate_gt_anchor.generate_gt_anchor(img, box, anchor_width=16, draw_img_gt=img)     # anchor_width=16 框就是i+15共16點，i自己是起點 , draw_img_gt=img
                # print(rr)
                # print(pt)  # [[(128, 331), (143, 331), (143, 362), (128, 362)], [(144, 329), (159, 329), (159, 361), (144, 361)]]
                for p in pt:
                    newtext.append({'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': p, 'difficult': False})
    #     newtext.append({'label': 'textbox', 'line_color': (60, 330, 100, 50), 'fill_color': (60, 330, 100, 50), 'points': points, 'difficult': False})
    shapes =  newtext
    return nfilename, shapes  
    # return nfilename, bbox

def main():
    '''
    將 text-detection-ocr\prepa_ctpn_longbox_n_img.py 處理的輸出 outbox.txt 讀近來轉成 shapes 給 savePascalVocFormat 輸出成XML格式
    傾斜的box用工具generate_gt_anchor.generate_gt_anchor都會切成text
    水平的都用原方法(一格一格計算)處理成text 
    '''
    spath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\temp_id_data\\'   # 500\\
    smode = 'IA0019\\'
    # tpath = 'C:\\Application\\Develop\\text-detection-ocr\\data\\id_data\\' + smode    # 這沒用，XML內容為目前路徑不影響實際功能 tpath為未來路徑所以不能用會帶不出XML中的影像尺寸
    sfilename = spath+smode+'outbox.txt'
    i = 0
    with open(sfilename) as fp:
        for line in fp:
            # print(line)
            i+=1
            nfilename, shapes = createnewPascalshapesFormat(line, spath+smode+line.split(' ')[0])
            print(nfilename, i)
            xfilename = spath+smode+nfilename.split('.jpg')[0]+'.xml'
            # xfilename 就是輸出XML檔案的檔名(目前路徑)
            # imagePath 需要計算尺寸，所以要給實際影像檔案位置 路徑(目前路徑)+檔名
            # shapes {'label': 'text', 'line_color': (160, 67, 78, 100), 'fill_color': (160, 67, 78, 100), 'points': [(leftx, ymin), (rightx, ymin), (rightx, ymax), (leftx, ymax)], 'difficult': False}
            savePascalVocFormat(filename=xfilename, imagePath=spath+smode+nfilename, shapes=shapes)
    os.remove(sfilename)  # 移掉免得又跑一次=做白工
    return print('job done.')

if __name__ == "__main__":
    main()
else:
    print('load xml-parse-ctpn ok.')    
